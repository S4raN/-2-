#include <iostream>
#include <locale.h>
#include <concepts>
#include <cmath>

using namespace std;

// ����� latitude  = ������  longitude = �������


template <typename T, size_t Size>
class Vector {
public:
    Vector() {
        for (size_t i = 0; i < Size; i++) {
            data[i] = T();
        }
    }
    T distance(const Vector<T, Size>& other) {
        T result = T();
            for (size_t i = 0; i < Size; i++) {result += pow(data[i] - other.data[i], 2);
        }
        return sqrt(result);
    }
private:
    T data[Size];
};

template <typename T>
concept AddAndMultiplyable = requires(T a, T b) {
    { a + b };
    { a * b };
};

template <typename T, size_t Size>
requires AddAndMultiplyable<T>
class GeoVector {
public:
    GeoVector() {
        data[0] = T();
        data[1] = T();
    }
    T distance(const GeoVector<T, Size>& other) {
        T delta_l = other.data[1] - data[1];
        T sin_f1 = sin(data[0]);
        T cos_f1 = cos(data[0]);
        T sin_f2 = sin(other.data[0]);
        T cos_f2 = cos(other.data[0]);
        T delta_d = atan(sqrt(pow(cos_f2 * sin(delta_l),2) + pow(cos_f1 * sin_f2 - sin_f1 * cos_f2 * cos(delta_l), 2))/(sin_f1 * sin_f2 + cos_f1 * cos_f2 * cos(delta_l)));
    return delta_d * 6371;
    }

private:
    T data[Size];
};

class GeoCoordinate {
public:
    GeoCoordinate() : latitude(0.0), longitude(0.0) {}

    void setLatitude(double lat) {
        latitude = lat;
    }

    void setLongitude(double lon) {
        longitude = lon;
    }

    void printDegrees() {
        cout << "������: " << latitude << endl;
        cout << "�������: " << longitude << endl;
    }

    void printRadians() {
        double rad_latitude = latitude * M_PI / 180.0;
        double rad_longitude = longitude * M_PI / 180.0;
        cout << "������: " << rad_latitude << " ������" << endl;
        cout << "�������: " << rad_longitude << " ������" << endl;
    }

private:
    double latitude;
    double longitude;
};

int main() {

    setlocale (LC_ALL,"Rus");

    GeoCoordinate city1;
    city1.setLatitude(48.71385);
    city1.setLongitude(44.51351);

    GeoCoordinate city2;
    city2.setLatitude(55.75417);
    city2.setLongitude(37.62131);

    GeoVector<double, 2> distance;
    distance.setCoordinates(city1, city2);

    cout << "��������� ����� ����� �������� " << distance.distance() << " ��" << endl;

    return 0;
}
