#include <iostream>
#include <type_traits>
#include <iterator>


using namespace std;

template <typename T>
concept Comparable = requires(T a, T b) {
    { a < b } -> convertible_to<bool>;
};

template <Comparable... Args>
bool isIncreasing(Args... args) {
    return (args < ...);
}

int main() {
    cout << boolalpha;

    cout << isIncreasing(1, 2, 3, 4, 5) << endl;
    cout << isIncreasing(5, 4, 3, 2, 1) << endl;
    cout << isIncreasing(1.5, 2.5, 3.5, 4.5) << endl;


    return 0;
}
