#include<iostream>
#include<typeinfo>
#include<locale.h>

using namespace std;
int main()
try{
setlocale (LC_ALL,"Rus");

class Base { virtual void foo() {} };
        class Derived : public Base {};
        Base* basePtr = new Base();
        Derived* derivedPtr = dynamic_cast<Derived*>(basePtr);
        delete basePtr; // ������������ ���

    catch (const std::bad_cast& ex) {
    std::cout << "std::bad_cast: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        std::cout << "std::exception: " << ex.what() << std::endl;
    }
    catch (...) {
        std::cout << "����������� ������" << std::endl;
    }

    return 0;

}
