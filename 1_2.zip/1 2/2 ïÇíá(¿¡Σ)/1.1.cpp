#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include <exception>
#include <ctime>

using namespace std;

class ErrorHandler { private:
string errorMsg;
time_t errorTime;

public:
ErrorHandler(const string &err) : errorMsg(err), errorTime(time(nullptr)) {}
void reportError() {
cout << "Error: " << errorMsg << "\n";
cout << ctime(&errorTime) << endl;
}
};

int main() { ifstream file; string filename; cout << "Enter the filename: "; cin >> filename; ErrorHandler err("File opening error");
try {
file.open(filename);
}
catch (const exception &e) {
err.reportError();
throw e;
}

if (!file.is_open()) {
cerr << "File not found" << endl;
return 1;
}
string line;
int num1, num2;
}
